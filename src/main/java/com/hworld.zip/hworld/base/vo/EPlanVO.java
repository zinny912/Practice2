package com.hworld.base.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EPlanVO {
	//부가서비스VO 
    private Integer ePlanNum;
    private String ePlanName;
    private Integer ePlanPrice;
    private String ePlanExplain;
    private String ePlanExplainSM;
}
