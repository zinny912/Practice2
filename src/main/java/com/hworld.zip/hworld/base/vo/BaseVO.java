package com.hworld.base.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BaseVO {
	//공통코드
	private String type;
	private String code;
	private String vlaue;
	private String note;
	
}
